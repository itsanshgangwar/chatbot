"""
Runs compose() over the 30 canonical (merchant, trigger[, customer]) test pairs
and writes submission.jsonl. Run from the submission/ folder with the expanded
dataset available at ../dataset_expanded (or pass --dataset).
"""
import argparse
import json
from pathlib import Path

from bot import compose


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="../dataset_expanded")
    ap.add_argument("--out", default="submission.jsonl")
    args = ap.parse_args()

    ds = Path(args.dataset)
    test_pairs = load(ds / "test_pairs.json")["pairs"]

    categories = {p.stem: load(p) for p in (ds / "categories").glob("*.json")}
    merchants = {p.stem: load(p) for p in (ds / "merchants").glob("*.json")}
    customers = {p.stem: load(p) for p in (ds / "customers").glob("*.json")}
    triggers = {p.stem: load(p) for p in (ds / "triggers").glob("*.json")}

    lines = []
    for pair in test_pairs:
        merchant = merchants[pair["merchant_id"]]
        trigger = triggers[pair["trigger_id"]]
        customer = customers.get(pair["customer_id"]) if pair.get("customer_id") else None
        category = categories[merchant["category_slug"]]

        result = compose(category, merchant, trigger, customer)
        lines.append({"test_id": pair["test_id"], **result})

    with open(args.out, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(json.dumps(line, ensure_ascii=False) + "\n")
    print(f"Wrote {len(lines)} lines to {args.out}")


if __name__ == "__main__":
    main()
