"""
Multi-turn conversation handling — optional but tackles the brief's
"open challenges" (§12): auto-reply detection, intent-transition routing,
knowing when to stop.

respond(state, merchant_message) -> dict with keys: action ("send"/"wait"/"end"), body?, cta?, rationale
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional


# =============================================================================
# Conversation state
# =============================================================================

@dataclass
class ConversationState:
    conversation_id: str
    merchant_id: str
    customer_id: Optional[str] = None
    turn_number: int = 0
    history: list = field(default_factory=list)          # [{"from": "vera"/"merchant", "body": str}]
    sent_bodies: list = field(default_factory=list)       # anti-repetition check
    unanswered_nudges: int = 0
    ended: bool = False


# =============================================================================
# Auto-reply detection
# =============================================================================

AUTO_REPLY_PATTERNS = [
    r"thank you for (contacting|reaching out)",
    r"we (will|shall) get back to you",
    r"automated (assistant|reply|message)",
    r"hamari team tak pahuncha",
    r"we are currently (closed|unavailable)",
    r"aapki jaankari ke liye",
    r"main ek automated",
]

def is_auto_reply(state: ConversationState, message: str) -> bool:
    """Detect merchant WhatsApp Business canned auto-replies.
    Two signals: (a) matches a known canned-reply phrasing, or
    (b) same message sent verbatim 3+ times in this conversation (per brief's hint)."""
    normalized = message.strip().lower()
    if any(re.search(p, normalized) for p in AUTO_REPLY_PATTERNS):
        return True
    repeats = sum(1 for h in state.history if h["from"] == "merchant" and h["body"].strip().lower() == normalized)
    return repeats >= 2  # this would be the 3rd occurrence


# =============================================================================
# Intent detection — explicit "let's go" should route to action, not another
# qualifying question (anti-pattern D in the brief)
# =============================================================================

INTENT_YES_PATTERNS = [
    r"\byes\b", r"\bok(ay)?\b", r"let'?s do it", r"go ahead", r"\bhaan\b", r"chalega",
    r"\bsure\b", r"start karo", r"karo", r"i want to join", r"judrna hai", r"sign me up",
]
NOT_INTERESTED_PATTERNS = [
    r"not interested", r"nahi chahiye", r"\bstop\b", r"unsubscribe", r"don'?t (contact|message) me",
    r"no thanks", r"nahi", r"leave me alone",
]

def detect_intent(message: str) -> str:
    normalized = message.strip().lower()
    if any(re.search(p, normalized) for p in NOT_INTERESTED_PATTERNS):
        return "decline"
    if any(re.search(p, normalized) for p in INTENT_YES_PATTERNS):
        return "accept"
    return "neutral"


# =============================================================================
# Main multi-turn responder
# =============================================================================

MAX_UNANSWERED_NUDGES = 3

def respond(state: ConversationState, merchant_message: str) -> dict:
    state.turn_number += 1
    state.history.append({"from": "merchant", "body": merchant_message})

    # 1. Auto-reply detection: try once more, then exit gracefully.
    if is_auto_reply(state, merchant_message):
        auto_reply_count = sum(
            1 for h in state.history if h["from"] == "merchant"
        )  # rough count of merchant turns so far
        if auto_reply_count <= 1:
            body = "Got it — before this goes to your team, want to take a quick look yourself? 2-min ask."
            return _send(state, body, "open_ended",
                          "First auto-reply detected; one lightweight nudge to reach a human before exiting")
        body = "No worries, I'll connect with the owner/manager directly. Best of luck! 🙂"
        return _end(state, "Second auto-reply confirms this is a bot; exiting gracefully without wasting turns")

    # 2. Explicit decline -> graceful exit immediately.
    intent = detect_intent(merchant_message)
    if intent == "decline":
        body = "Understood, won't bother you about this again. Reach out anytime you need something. 🙏"
        return _end(state, "Merchant explicitly declined; exiting immediately and politely")

    # 3. Explicit accept -> route straight to action, skip further qualification.
    if intent == "accept":
        body = "Great — starting now. I'll set it up and send you a confirmation shortly."
        return _send(state, body, "none",
                      "Merchant gave explicit intent signal; routing directly to action instead of re-qualifying "
                      "(avoids the intent-handoff failure called out in the brief)")

    # 4. Neutral reply — count towards unanswered-nudge budget only if it's not
    #    actually engaging with the question (short filler / off-topic).
    off_topic = len(merchant_message.strip()) > 0 and detect_intent(merchant_message) == "neutral" \
        and not _looks_engaged(merchant_message)
    if off_topic:
        state.unanswered_nudges += 1
        if state.unanswered_nudges >= MAX_UNANSWERED_NUDGES:
            body = "I'll leave this here for now — message me anytime if it's useful later. 🙂"
            return _end(state, f"{MAX_UNANSWERED_NUDGES} unanswered/off-track nudges reached; exiting gracefully")

    # 5. Default: acknowledge + advance the conversation with the next best step.
    body = "Got it — here's the next step, just say go and I'll take care of it."
    return _send(state, body, "binary", "Acknowledged merchant's message and advanced with a low-friction next step")


def _looks_engaged(message: str) -> bool:
    """Heuristic: a real question or a substantive reply counts as engagement,
    even if it's not a clean yes/no."""
    return "?" in message or len(message.split()) >= 4


def _send(state: ConversationState, body: str, cta: str, rationale: str) -> dict:
    if body in state.sent_bodies:
        body = body + " (following up)"  # anti-repetition guard
    state.sent_bodies.append(body)
    state.history.append({"from": "vera", "body": body})
    return {"action": "send", "body": body, "cta": cta, "rationale": rationale}


def _end(state: ConversationState, rationale: str) -> dict:
    state.ended = True
    return {"action": "end", "rationale": rationale}
