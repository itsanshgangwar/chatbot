"""
magicpin AI Challenge — "Vera-but-better" bot
================================================

compose(category, merchant, trigger, customer=None) -> dict
    Returns: body, cta, send_as, suppression_key, rationale

Architecture
------------
Two composer paths, tried in order:

1. LLM composer (llm_compose)      — calls Claude with a system prompt that
   encodes the full rulebook from challenge-brief.md (voice, specificity,
   compulsion levers, anti-patterns). Used automatically if ANTHROPIC_API_KEY
   is set in the environment. This is the intended "real" path — an LLM
   reading structured context almost always beats a fixed template because
   it can weave together whichever facts are actually relevant for THIS
   merchant + THIS trigger, in THIS merchant's voice.

2. Deterministic template composer (template_compose) — a rule-based
   fallback with one handler per trigger `kind`. It never calls out to
   the network, is fully offline-testable, is 100% deterministic
   (needed for the "must be deterministic" submission requirement even
   with temperature=0 LLM variance), and guarantees the bot never crashes
   or times out even if the LLM call fails/is unavailable.

`compose()` always tries the LLM first (if configured) and falls back to
the template composer on any failure — so the bot never returns nothing.
"""

from __future__ import annotations

import json
import os
import random
from typing import Any, Optional

# =============================================================================
# Public entrypoint
# =============================================================================

def compose(
    category: dict,
    merchant: dict,
    trigger: dict,
    customer: Optional[dict] = None,
) -> dict:
    """Main composition entrypoint required by the challenge spec."""
    try:
        if os.environ.get("ANTHROPIC_API_KEY"):
            result = llm_compose(category, merchant, trigger, customer)
            if result and result.get("body"):
                return _finalize(result, trigger, customer)
    except Exception:
        pass  # fall through to deterministic composer — never let the bot go silent
    result = template_compose(category, merchant, trigger, customer)
    return _finalize(result, trigger, customer)


def _finalize(result: dict, trigger: dict, customer: Optional[dict]) -> dict:
    """Fill in fields the composer didn't set, guarantee schema completeness."""
    result.setdefault("send_as", "merchant_on_behalf" if customer else "vera")
    result.setdefault("suppression_key", trigger.get("suppression_key", ""))
    result.setdefault("cta", "none")
    result.setdefault("rationale", "composed from category+merchant+trigger context")
    return {
        "body": result["body"].strip(),
        "cta": result["cta"],
        "send_as": result["send_as"],
        "suppression_key": result["suppression_key"],
        "rationale": result["rationale"],
    }


# =============================================================================
# 1. LLM composer
# =============================================================================

SYSTEM_PROMPT = """You are Vera-but-better, an AI marketing assistant that messages Indian local-business \
merchants (and sometimes their customers) on WhatsApp on behalf of magicpin.

You will be given four JSON context blocks: CATEGORY, MERCHANT, TRIGGER, and optionally CUSTOMER.
Compose the single next WhatsApp message.

Hard rules:
- Never invent facts. Only use numbers, offers, names, quotes, and citations that literally appear \
in the provided JSON. If you want to reference something not present, don't.
- Anchor on ONE concrete, verifiable fact from the context (a number, a date, a source, a headline). \
Generic framings like "grow your business" or "10% off" are a failure.
- Match CATEGORY.voice.tone exactly (e.g. peer_clinical for dentists is not the same as playful for salons). \
Never use CATEGORY.voice.vocab_taboo words. Prefer CATEGORY.voice.vocab_allowed words where natural.
- If MERCHANT.identity.languages includes "hi" (or CUSTOMER.identity.language_pref mentions hi), write in \
natural Hindi-English code-mix, the way an Indian professional texts a colleague. Otherwise plain English.
- Single primary call-to-action. Prefer a binary yes/no ("Reply YES / STOP") for action-triggers; use \
open-ended only when you're inviting a reply that isn't binary; use none for pure FYI.
- Use at least one compulsion lever: specificity, loss aversion, social proof, effort externalization, \
curiosity, reciprocity, asking the merchant a question, or a single binary commitment.
- No long preambles ("I hope you're doing well..."). Don't re-introduce yourself if CONVERSATION_HISTORY \
already exists. The CTA should land in the last sentence. Never use multiple CTAs.
- If send target is a customer (CUSTOMER block present), speak as the merchant's business ("Dr. Meera's \
clinic here"), not as Vera. Never make medical/overclaim promises to customers.
- Keep it short — 2 to 5 sentences, WhatsApp length, not an essay.

Return ONLY a JSON object with keys: body (string), cta (one of "binary", "open_ended", "none"), rationale \
(one short sentence on why this message + which levers you used). No markdown, no preamble, JSON only.
"""


def llm_compose(category: dict, merchant: dict, trigger: dict, customer: Optional[dict]) -> Optional[dict]:
    """Calls the Anthropic API. Returns None (triggering fallback) on any problem."""
    import urllib.request

    user_blocks = {
        "CATEGORY": category,
        "MERCHANT": merchant,
        "TRIGGER": trigger,
    }
    if customer:
        user_blocks["CUSTOMER"] = customer

    user_prompt = "Compose the message.\n\n" + "\n\n".join(
        f"{k}:\n{json.dumps(v, ensure_ascii=False, indent=2)}" for k, v in user_blocks.items()
    )

    payload = json.dumps({
        "model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
        "max_tokens": 500,
        "temperature": 0,  # deterministic, per submission requirement
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_prompt}],
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "x-api-key": os.environ["ANTHROPIC_API_KEY"],
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = json.loads(resp.read())

    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    text = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    parsed = json.loads(text)
    if not parsed.get("body"):
        return None
    return {
        "body": parsed["body"],
        "cta": parsed.get("cta", "open_ended"),
        "rationale": parsed.get("rationale", "LLM-composed from full context"),
    }


# =============================================================================
# 2. Deterministic template composer — one handler per trigger kind
# =============================================================================

def _first_name(merchant: dict) -> str:
    ident = merchant.get("identity", {})
    return ident.get("owner_first_name") or ident.get("name", "there").split()[0]

def _is_hindi_mix(merchant: dict, customer: Optional[dict]) -> bool:
    if customer:
        return "hi" in (customer.get("identity", {}).get("language_pref", "") or "")
    return "hi" in merchant.get("identity", {}).get("languages", [])

def _salutation(category: dict, merchant: dict) -> str:
    examples = category.get("voice", {}).get("salutation_examples", [])
    fname = _first_name(merchant)
    for ex in examples:
        if "{first_name}" in ex:
            return ex.replace("{first_name}", fname)
    return fname

def _top_digest(category: dict) -> Optional[dict]:
    digest = category.get("digest", [])
    return digest[0] if digest else None

def _best_offer(category: dict, merchant: dict, customer: Optional[dict] = None) -> Optional[dict]:
    active = [o for o in merchant.get("offers", []) if o.get("status") == "active"]
    if active:
        return active[0]
    catalog = category.get("offer_catalog", [])
    if not catalog:
        return None
    if customer:
        is_senior = customer.get("identity", {}).get("senior_citizen")
        is_repeat = customer.get("state") not in (None, "new")
        if is_senior:
            senior_offer = next((o for o in catalog if o.get("audience") == "senior"), None)
            if senior_offer:
                return senior_offer
        if is_repeat:
            repeat_offer = next((o for o in catalog if o.get("audience") in ("repeat_user", "all")), None)
            if repeat_offer:
                return repeat_offer
    return catalog[0]

def _peer_stat_gap(category: dict, merchant: dict) -> Optional[str]:
    peer = category.get("peer_stats", {})
    perf = merchant.get("performance", {})
    if peer.get("avg_ctr") and perf.get("ctr") is not None and perf["ctr"] < peer["avg_ctr"]:
        return f"your CTR is {perf['ctr']*100:.1f}% vs a peer average of {peer['avg_ctr']*100:.1f}%"
    return None


def _hi(en: str, hi: str, use_hindi: bool) -> str:
    return hi if use_hindi else en


# ---- per-kind handlers -------------------------------------------------

def h_research_digest(category, merchant, trigger, customer, hindi):
    item = _top_digest(category)
    name = _salutation(category, merchant)
    if not item:
        return {"body": f"{name}, nothing new in this week's digest for your category yet.",
                "cta": "none", "rationale": "no digest item available; sent minimal FYI"}
    src = item.get("source", "")
    segment = item.get("patient_segment") or item.get("actionable", "")
    segment_phrase = f" for your {segment.replace('_',' ')} cases" if segment else ""
    trial_phrase = f" ({item['trial_n']}-patient trial)" if item.get("trial_n") else ""
    body = (
        f"{name}, {src.split(',')[0]} dropped something relevant"
        f"{segment_phrase}: "
        f"{item['title']}"
        f"{trial_phrase}. "
        + _hi(
            f"Want me to pull the abstract and draft something you can share? — {src}",
            f"Chahiye toh main abstract nikaal ke ek draft bhi bana deti hoon — {src}",
            hindi,
        )
    )
    return {"body": body, "cta": "open_ended",
            "rationale": "Specificity (trial size, source) + reciprocity (offered to draft) + curiosity"}


def h_perf_spike(category, merchant, trigger, customer, hindi):
    perf = merchant.get("performance", {})
    delta = perf.get("delta_7d", {}).get("views_pct")
    name = _salutation(category, merchant)
    pct = f"{delta*100:.0f}%" if delta else "up"
    body = (
        f"{name}, your profile views are {pct} vs last week ({perf.get('views','')} views, 30d). "
        + _hi("Good moment to push a fresh post while eyes are on you — want a draft?",
              "Accha time hai ek fresh post daalne ka jab tak log dekh rahe hain — draft bana doon?", hindi)
    )
    return {"body": body, "cta": "binary",
            "rationale": "Specificity (real % + view count) + effort externalization + binary CTA"}


def h_perf_dip(category, merchant, trigger, customer, hindi):
    perf = merchant.get("performance", {})
    delta = perf.get("delta_7d", {}).get("calls_pct")
    name = _salutation(category, merchant)
    pct = f"{abs(delta)*100:.0f}%" if delta else "down"
    gap = _peer_stat_gap(category, merchant)
    body = (
        f"{name}, calls dropped {pct} week-over-week"
        f"{(' — ' + gap) if gap else ''}. "
        + _hi("Want me to check what changed and fix it? 2-min look.",
              "Check karke dekhoon kya wajah hai? 2 minute ka kaam hai.", hindi)
    )
    return {"body": body, "cta": "binary",
            "rationale": "Loss aversion (specific drop %) + peer comparison + low-friction CTA"}


def h_recall_due(category, merchant, trigger, customer, hindi):
    offer = _best_offer(category, merchant)
    cname = customer.get("identity", {}).get("name", "there") if customer else "there"
    mname = merchant.get("identity", {}).get("name", "")
    last_visit = customer.get("relationship", {}).get("last_visit", "") if customer else ""
    offer_line = f" {offer['title']}." if offer else ""
    body = (
        f"Hi {cname}, {mname} here. "
        + _hi(f"It's been a while since your last visit ({last_visit}) — your recall checkup is due.",
              f"Aapki last visit ({last_visit}) ko time ho gaya hai — recall checkup due hai.", hindi)
        + f"{offer_line} "
        + _hi("Reply 1 to book, or tell us a time that works.",
              "Reply 1 book karne ke liye, ya apna time bata dijiye.", hindi)
    )
    return {"body": body, "cta": "binary",
            "rationale": "Merchant-on-behalf recall nudge with real offer + low-friction slot CTA"}


def h_renewal_due(category, merchant, trigger, customer, hindi):
    sub = merchant.get("subscription", {})
    name = _salutation(category, merchant)
    days = sub.get("days_remaining")
    body = (
        f"{name}, your {sub.get('plan','')} plan has {days} days left. "
        + _hi("Renew now to avoid any listing downtime — reply YES and I'll send the link.",
              "Abhi renew kar lijiye taaki listing band na ho — YES reply kijiye, link bhej deti hoon.", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "Loss aversion (concrete days_remaining) + binary CTA"}


def h_festival_upcoming(category, merchant, trigger, customer, hindi):
    fest = trigger.get("payload", {}).get("festival") or trigger.get("payload", {}).get("name", "the festival")
    days = trigger.get("payload", {}).get("days_to_go")
    offer = _best_offer(category, merchant)
    name = _salutation(category, merchant)
    when = f"in {days} days" if days else "coming up"
    offer_line = f" A {offer['title']} push usually does well for this." if offer else ""
    body = (
        f"{name}, {fest} is {when}.{offer_line} "
        + _hi("Want me to draft a festival post + offer for your profile?",
              "Chahiye toh main festival post + offer ka draft bana doon?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Timely trigger (days_to_go) + effort externalization"}


def h_competitor_opened(category, merchant, trigger, customer, hindi):
    dist = trigger.get("payload", {}).get("distance_km")
    name = _salutation(category, merchant)
    dist_line = f" ({dist} km away)" if dist else ""
    body = (
        f"{name}, a new competitor listed on Google{dist_line} in your locality. "
        + _hi("Your reviews and photos are still your edge — want me to check what's outdated on your profile?",
              "Aapke reviews aur photos abhi bhi aapki strength hain — profile check karoon kya outdated hai?", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "Loss aversion + social proof framing, low-friction CTA"}


def h_milestone_reached(category, merchant, trigger, customer, hindi):
    milestone = trigger.get("payload", {}).get("milestone") or trigger.get("payload", {}).get("description")
    name = _salutation(category, merchant)
    body = (
        f"{name}, milestone unlocked"
        f"{(': ' + str(milestone)) if milestone else ''}! "
        + _hi("Worth a shoutout post — want me to draft one?",
              "Isko ek post mein daalna chahiye — draft bana doon?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Social proof + reciprocity + curiosity"}


def h_curious_ask_due(category, merchant, trigger, customer, hindi):
    name = _salutation(category, merchant)
    body = (
        f"{name}, quick one — "
        + _hi("what's the most-asked service/question at your counter this week? Helps me tailor what I post for you.",
              "is hafte sabse zyada kaun sa sawal/service pucha gaya? Isse aapke liye better post bana paungi.", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "'Asking the merchant' lever (underused per brief) — pure curiosity/engagement"}


def h_chronic_refill_due(category, merchant, trigger, customer, hindi):
    cname = customer.get("identity", {}).get("name", "there") if customer else "there"
    mname = merchant.get("identity", {}).get("name", "")
    services = [s for s in customer.get("relationship", {}).get("services_received", []) if s and s != "..."] \
        if customer else []
    med = services[-1].replace("chronic_rx_", "").replace("_", " ") if services else "regular medicine"
    body = (
        f"Hi {cname}, {mname} here. "
        + _hi(f"Time for a refill on your {med} — want us to keep it ready for pickup?",
              f"aapke {med} ka refill time ho gaya hai — pickup ke liye ready rakhein?", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "Customer-facing refill reminder, effort externalization"}


def h_review_theme_emerged(category, merchant, trigger, customer, hindi):
    themes = merchant.get("review_themes", [])
    theme = themes[0] if themes else None
    name = _salutation(category, merchant)
    if not theme:
        return {"body": f"{name}, a review theme came up recently worth a look.", "cta": "none",
                "rationale": "no theme detail available"}
    if theme.get("sentiment") == "neg":
        body = (
            f"{name}, {theme['occurrences_30d']} reviews this month mention \"{theme['theme'].replace('_',' ')}\". "
            + _hi("Worth addressing directly — want a template reply I can help you post?",
                  "Isko address karna theek rahega — reply template chahiye?", hindi)
        )
    else:
        body = (
            f"{name}, {theme['occurrences_30d']} reviews this month praised \"{theme['theme'].replace('_',' ')}\". "
            + _hi("That's a strong hook for your next post — want me to draft it?",
                  "Yeh agla post ke liye accha angle hai — draft bana doon?", hindi)
        )
    return {"body": body, "cta": "open_ended", "rationale": "Specificity (occurrence count + verbatim theme) + reciprocity"}


def h_dormant_with_vera(category, merchant, trigger, customer, hindi):
    name = _salutation(category, merchant)
    signals = merchant.get("signals", [])
    stale = next((s for s in signals if "stale" in s), None)
    hook = f" Also noticed {stale.replace('_',' ').replace(':',' — ')}." if stale else ""
    body = (
        f"{name}, haven't heard from you in a bit.{hook} "
        + _hi("No pressure — just say the word if you want me to look at anything.",
              "Koi jaldi nahi — bas bataiye agar kuch dekhna hai.", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Low-pressure re-engagement, specificity if a signal exists"}


def h_appointment_tomorrow(category, merchant, trigger, customer, hindi):
    cname = customer.get("identity", {}).get("name", "there") if customer else "there"
    mname = merchant.get("identity", {}).get("name", "")
    time_ = trigger.get("payload", {}).get("time") or trigger.get("payload", {}).get("slot", "")
    body = (
        f"Hi {cname}, {mname} here — "
        + _hi(f"reminder for your appointment tomorrow{(' at ' + time_) if time_ else ''}.",
              f"kal ke appointment{(' ' + time_ + ' baje') if time_ else ''} ka reminder.", hindi)
        + " " + _hi("Reply 1 to confirm, 2 to reschedule.", "Confirm ke liye 1, reschedule ke liye 2 reply kijiye.", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "Customer-facing reminder, binary confirm/reschedule"}


def h_customer_lapsed(category, merchant, trigger, customer, hindi):
    cname = customer.get("identity", {}).get("name", "there") if customer else "there"
    mname = merchant.get("identity", {}).get("name", "")
    offer = _best_offer(category, merchant, customer)
    offer_line = f" {offer['title']} on us this time." if offer else ""
    is_pharmacy = category.get("slug") == "pharmacies"
    cta_text = _hi("Swing by or order this week?" if is_pharmacy else "Want to book a slot this week?",
                    "Is hafte order/visit karenge?" if is_pharmacy else "Is hafte slot book karna chahenge?",
                    hindi)
    body = f"Hi {cname}, {mname} here — it's been a while!{offer_line} {cta_text}"
    return {"body": body, "cta": "binary", "rationale": "Winback with real offer, low-friction binary CTA"}


def h_active_planning_intent(category, merchant, trigger, customer, hindi):
    """Merchant already said yes to something — action mode, not qualification (anti-pattern D)."""
    topic = trigger.get("payload", {}).get("intent_topic", "that").replace("_", " ")
    name = _salutation(category, merchant)
    body = (
        f"{name}, great — here's a first draft for {topic}: pricing tiers, a sample post, and next steps. "
        + _hi("Say go and I'll set it live.", "Go boliye, main isse live kar deti hoon.", hindi)
    )
    return {"body": body, "cta": "binary",
            "rationale": "Intent already confirmed by merchant — routes straight to action, not another qualifying question"}


def h_ipl_match_today(category, merchant, trigger, customer, hindi):
    name = _salutation(category, merchant)
    body = (
        f"{name}, "
        + _hi("match day traffic usually spikes footfall in your area tonight — want a quick match-day offer post?",
              "aaj match hai, aas paas footfall badhta hai — match-day offer post chalayein?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Local event tie-in + effort externalization"}


def h_category_seasonal(category, merchant, trigger, customer, hindi):
    beats = category.get("seasonal_beats", [])
    beat = beats[0] if beats else None
    name = _salutation(category, merchant)
    note = beat.get("note") if beat else "a seasonal shift"
    body = (
        f"{name}, seasonal pattern for your category: {note}. "
        + _hi("Worth planning content around this now — want a draft?",
              "Abhi se content plan karna theek rahega — draft chahiye?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Category seasonal_beats specificity + reciprocity"}


def h_supply_alert(category, merchant, trigger, customer, hindi):
    item = trigger.get("payload", {}).get("item", "an item")
    name = _salutation(category, merchant)
    body = f"{name}, heads up — {item} showing low stock signals in your area this week. Worth checking your inventory before demand picks up."
    return {"body": body, "cta": "none", "rationale": "Pure ops FYI, no CTA needed"}


def h_regulation_change(category, merchant, trigger, customer, hindi):
    digest = [d for d in category.get("digest", []) if d.get("kind") == "compliance"]
    item = digest[0] if digest else _top_digest(category)
    name = _salutation(category, merchant)
    if not item:
        return {"body": f"{name}, a regulation update came in — no details loaded yet.", "cta": "none",
                "rationale": "no compliance digest item available"}
    body = (
        f"{name}, {item.get('source','')}: {item['title']}. "
        f"{item.get('actionable','')} "
        + _hi("Want me to flag exactly what applies to your setup?",
              "Aapke setup pe kya apply hota hai, wo bata doon?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Compliance specificity + source citation, avoids scaremongering"}


def h_wedding_package_followup(category, merchant, trigger, customer, hindi):
    name = _salutation(category, merchant)
    offer = _best_offer(category, merchant)
    offer_line = f" ({offer['title']})" if offer else ""
    body = (
        f"{name}, wedding season enquiries are usually strong right now. "
        + _hi(f"Want me to push your package{offer_line} to your recent enquirers?",
              f"Aapka package{offer_line} recent enquiries ko bhej doon?", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "Seasonal upsell + effort externalization"}


def h_winback_eligible(category, merchant, trigger, customer, hindi):
    return h_customer_lapsed(category, merchant, trigger, customer, hindi)


def h_cde_opportunity(category, merchant, trigger, customer, hindi):
    digest = [d for d in category.get("digest", []) if d.get("kind") == "cde"]
    item = digest[0] if digest else None
    name = _salutation(category, merchant)
    if not item:
        return {"body": f"{name}, a CDE opportunity came up — details pending.", "cta": "none",
                "rationale": "no cde digest item available"}
    date = item.get("date", "")
    body = (
        f"{name}, {item['title']} — {date.split('T')[0] if date else ''}, {item.get('credits','')} credits. "
        f"{item.get('actionable','')} "
        + _hi("Want the registration link?", "Registration link bhej doon?", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "CDE specificity (date, credits) + low-friction CTA"}


def h_gbp_unverified(category, merchant, trigger, customer, hindi):
    name = _salutation(category, merchant)
    body = (
        f"{name}, your Google Business Profile is still unverified — this caps your visibility in search. "
        + _hi("Takes 5 min, I can walk you through it now — go?",
              "5 minute ka kaam hai, main abhi guide kar sakti hoon — shuru karein?", hindi)
    )
    return {"body": body, "cta": "binary", "rationale": "Loss aversion (visibility cap) + effort externalization"}


def h_seasonal_perf_dip(category, merchant, trigger, customer, hindi):
    beats = category.get("seasonal_beats", [])
    beat = beats[0] if beats else None
    name = _salutation(category, merchant)
    note = f" ({beat['note']})" if beat else ""
    body = (
        f"{name}, this dip lines up with a known seasonal pattern{note} — not unusual, but worth a plan for the upswing. "
        + _hi("Want me to draft something ready for when demand picks back up?",
              "Demand wapas aane par ready rehne ke liye draft bana doon?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Reassurance + seasonal specificity + reciprocity"}


def h_generic(category, merchant, trigger, customer, hindi):
    name = _salutation(category, merchant)
    signals = merchant.get("signals", [])
    signal = signals[0].replace("_", " ").replace(":", " — ") if signals else None
    hook = f" Noticed: {signal}." if signal else ""
    body = (
        f"{name}, quick check-in.{hook} "
        + _hi("Anything you'd like me to look at?", "Kuch dekhna hai aapko?", hindi)
    )
    return {"body": body, "cta": "open_ended", "rationale": "Generic fallback using an available merchant signal"}


HANDLERS = {
    "research_digest": h_research_digest,
    "perf_spike": h_perf_spike,
    "perf_dip": h_perf_dip,
    "recall_due": h_recall_due,
    "renewal_due": h_renewal_due,
    "festival_upcoming": h_festival_upcoming,
    "competitor_opened": h_competitor_opened,
    "milestone_reached": h_milestone_reached,
    "curious_ask_due": h_curious_ask_due,
    "chronic_refill_due": h_chronic_refill_due,
    "review_theme_emerged": h_review_theme_emerged,
    "dormant_with_vera": h_dormant_with_vera,
    "appointment_tomorrow": h_appointment_tomorrow,
    "customer_lapsed_soft": h_customer_lapsed,
    "customer_lapsed_hard": h_customer_lapsed,
    "active_planning_intent": h_active_planning_intent,
    "ipl_match_today": h_ipl_match_today,
    "category_seasonal": h_category_seasonal,
    "supply_alert": h_supply_alert,
    "regulation_change": h_regulation_change,
    "wedding_package_followup": h_wedding_package_followup,
    "winback_eligible": h_winback_eligible,
    "cde_opportunity": h_cde_opportunity,
    "gbp_unverified": h_gbp_unverified,
    "seasonal_perf_dip": h_seasonal_perf_dip,
    "trial_followup": h_customer_lapsed,
}


def template_compose(category: dict, merchant: dict, trigger: dict, customer: Optional[dict]) -> dict:
    kind = trigger.get("kind", "")
    handler = HANDLERS.get(kind, h_generic)
    hindi = _is_hindi_mix(merchant, customer)
    try:
        return handler(category, merchant, trigger, customer, hindi)
    except Exception:
        return h_generic(category, merchant, trigger, customer, hindi)


if __name__ == "__main__":
    # tiny smoke test
    demo_category = {"slug": "dentists", "voice": {"tone": "peer_clinical"}, "digest": [
        {"title": "3-month recall cuts caries 38%", "source": "JIDA Oct 2026", "trial_n": 2100,
         "patient_segment": "high_risk_adults"}]}
    demo_merchant = {"identity": {"name": "Dr. Meera's Dental Clinic", "owner_first_name": "Meera",
                                   "languages": ["en", "hi"]},
                      "performance": {"views": 2410, "ctr": 0.021, "delta_7d": {"views_pct": 0.18}}}
    demo_trigger = {"kind": "research_digest", "suppression_key": "demo"}
    print(json.dumps(compose(demo_category, demo_merchant, demo_trigger), indent=2, ensure_ascii=False))
