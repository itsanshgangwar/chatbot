"""
Live-harness server — implements the 5 endpoints from challenge-testing-brief.md.
Run: uvicorn server:app --host 0.0.0.0 --port 8080
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import FastAPI
from pydantic import BaseModel

from bot import compose
from conversation_handlers import ConversationState, respond as ch_respond

app = FastAPI()
START = time.time()

# in-memory stores — fine per spec (no restart required during test window)
contexts: dict[tuple[str, str], dict] = {}          # (scope, context_id) -> {"version": int, "payload": dict}
conversations: dict[str, ConversationState] = {}     # conversation_id -> state
sent_trigger_ids: set[str] = set()                   # avoid re-sending same trigger twice


def _get(scope: str, context_id: Optional[str]) -> Optional[dict]:
    if not context_id:
        return None
    entry = contexts.get((scope, context_id))
    return entry["payload"] if entry else None


# =============================================================================
# GET /v1/healthz
# =============================================================================

@app.get("/v1/healthz")
async def healthz():
    counts = {"category": 0, "merchant": 0, "customer": 0, "trigger": 0}
    for (scope, _cid) in contexts.keys():
        counts[scope] = counts.get(scope, 0) + 1
    return {"status": "ok", "uptime_seconds": int(time.time() - START), "contexts_loaded": counts}


# =============================================================================
# GET /v1/metadata
# =============================================================================

@app.get("/v1/metadata")
async def metadata():
    return {
        "team_name": "Vera-but-better",
        "team_members": ["Claude"],
        "model": "claude-sonnet-4-6 (LLM path) + deterministic template fallback",
        "approach": "4-context prompt composer with per-trigger-kind template fallback; "
                    "multi-turn handler with auto-reply detection, intent-transition routing, graceful exit",
        "contact_email": "team@example.com",
        "version": "1.0.0",
        "submitted_at": datetime.now(timezone.utc).isoformat(),
    }


# =============================================================================
# POST /v1/context
# =============================================================================

class CtxBody(BaseModel):
    scope: str
    context_id: str
    version: int
    payload: dict[str, Any]
    delivered_at: str


@app.post("/v1/context")
async def push_context(body: CtxBody):
    key = (body.scope, body.context_id)
    cur = contexts.get(key)
    if cur and cur["version"] >= body.version:
        return {"accepted": False, "reason": "stale_version", "current_version": cur["version"]}
    contexts[key] = {"version": body.version, "payload": body.payload}
    return {
        "accepted": True,
        "ack_id": f"ack_{body.context_id}_v{body.version}",
        "stored_at": datetime.now(timezone.utc).isoformat(),
    }


# =============================================================================
# POST /v1/tick
# =============================================================================

class TickBody(BaseModel):
    now: str
    available_triggers: list[str] = []


@app.post("/v1/tick")
async def tick(body: TickBody):
    actions = []
    for trg_id in body.available_triggers:
        if trg_id in sent_trigger_ids:
            continue  # suppression: don't re-send the same trigger
        trigger = _get("trigger", trg_id)
        if not trigger:
            continue
        merchant_id = trigger.get("merchant_id")
        merchant = _get("merchant", merchant_id)
        if not merchant:
            continue
        category = _get("category", merchant.get("category_slug"))
        if not category:
            continue
        customer = _get("customer", trigger.get("customer_id"))

        result = compose(category, merchant, trigger, customer)
        conversation_id = f"conv_{merchant_id}_{trg_id}"
        conversations[conversation_id] = ConversationState(
            conversation_id=conversation_id, merchant_id=merchant_id,
            customer_id=trigger.get("customer_id"),
        )
        conversations[conversation_id].history.append({"from": "vera", "body": result["body"]})
        conversations[conversation_id].sent_bodies.append(result["body"])

        actions.append({
            "conversation_id": conversation_id,
            "merchant_id": merchant_id,
            "customer_id": trigger.get("customer_id"),
            "send_as": result["send_as"],
            "trigger_id": trg_id,
            "template_name": f"vera_{trigger.get('kind','generic')}_v1",
            "template_params": [merchant.get("identity", {}).get("name", "")],
            "body": result["body"],
            "cta": result["cta"],
            "suppression_key": result["suppression_key"],
            "rationale": result["rationale"],
        })
        sent_trigger_ids.add(trg_id)
        if len(actions) >= 20:  # per-tick action cap
            break
    return {"actions": actions}


# =============================================================================
# POST /v1/reply
# =============================================================================

class ReplyBody(BaseModel):
    conversation_id: str
    merchant_id: Optional[str] = None
    customer_id: Optional[str] = None
    from_role: str
    message: str
    received_at: str
    turn_number: int


@app.post("/v1/reply")
async def reply(body: ReplyBody):
    state = conversations.get(body.conversation_id)
    if state is None:
        state = ConversationState(conversation_id=body.conversation_id,
                                   merchant_id=body.merchant_id or "",
                                   customer_id=body.customer_id)
        conversations[body.conversation_id] = state
    result = ch_respond(state, body.message)
    return result


# =============================================================================
# POST /v1/teardown (optional)
# =============================================================================

@app.post("/v1/teardown")
async def teardown():
    contexts.clear()
    conversations.clear()
    sent_trigger_ids.clear()
    return {"status": "wiped"}
