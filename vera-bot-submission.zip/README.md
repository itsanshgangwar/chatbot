# Vera-but-better — submission README

## Approach

`compose(category, merchant, trigger, customer)` tries two composer paths, in order:

1. **LLM composer** (`llm_compose` in `bot.py`) — if `ANTHROPIC_API_KEY` is set, calls
   Claude with a system prompt that encodes the brief's full rulebook (voice/taboo
   vocab, specificity requirement, compulsion levers, single-CTA rule, no-fabrication
   rule, code-mix language rule) and the 4 context blocks as JSON. `temperature=0`
   for determinism. This is the intended production path — an LLM can weave together
   whichever facts are actually relevant for *this* merchant + *this* trigger, in a
   way a fixed template can't.
2. **Deterministic template composer** (`template_compose`) — one handler per
   `trigger.kind` (26 kinds covered, plus a generic fallback for anything unseen).
   Runs with zero network calls, is fully offline-testable, and guarantees the bot
   never goes silent or times out even if the LLM call fails. This is also what
   generated `submission.jsonl` in this environment (no internet access here to hit
   the Anthropic API), so it doubles as a live demonstration of the approach.

`conversation_handlers.py` implements the multi-turn `respond()` contract, targeting
the specific failure modes called out in the brief:
- **Auto-reply detection** — regex bank of common WhatsApp Business canned replies,
  plus the brief's own hint (same message verbatim 3+ times = auto-reply). Sends one
  lightweight nudge, then exits gracefully on the second detection (Pattern B).
- **Intent-transition routing** — explicit accept language ("yes", "let's do it",
  "haan", "chalega", "judrna hai") routes straight to action mode, skipping further
  qualification (fixes anti-pattern D from the brief).
- **Graceful exit** — explicit decline routes to an immediate polite exit; 3
  consecutive off-track/unengaged replies also triggers exit.
- **Anti-repetition** — `_send()` checks `sent_bodies` before resending anything
  verbatim.

`server.py` implements the 5 live-harness HTTP endpoints from
`challenge-testing-brief.md` (`/v1/context`, `/v1/tick`, `/v1/reply`, `/v1/healthz`,
`/v1/metadata`, plus optional `/v1/teardown`), wiring `bot.compose()` and
`conversation_handlers.respond()` behind an in-memory context store, keyed by
`(scope, context_id)` with version-based idempotency exactly as specified.

## Tradeoffs

- The template composer is intentionally conservative: it only ever inserts facts
  that literally exist in the passed-in dicts (no invented numbers/citations), at
  the cost of being less fluent/varied than a good LLM pass would be. In a real
  submission I'd run the LLM path and use the template composer purely as a
  fail-safe fallback + fast unit-test harness.
- Language handling is a simple heuristic (`languages` includes `"hi"` → sprinkle
  Hindi-English) rather than true code-mix generation — good enough for the
  template path, but the LLM path does this far more naturally per its system
  prompt instructions.
- Offer selection (`_best_offer`) does light audience-matching (senior citizen →
  senior discount; repeat customer → repeat-user offer) but doesn't do a full
  recommendation pass across the whole catalog.
- `respond()` state is a plain dataclass kept in-memory by the caller (or by
  `server.py`'s dict) — fine for the 60-minute test window, not meant to survive
  a restart, per the spec's own allowance.

## What additional context would have helped most

- A merchant-level "reply speed" / "prefers short vs. detailed" signal — several
  compulsion levers (effort externalization vs. curiosity) land differently
  depending on how much a given merchant likes to read.
- Explicit per-category examples of *bad* generated copy (not just good), to
  calibrate the line between "specific" and "overloaded with numbers."
- A canonical trigger→CTA-type mapping (which kinds are inherently binary vs.
  open-ended vs. none) would remove some guesswork from the template composer.

## Files

| File | Purpose |
|---|---|
| `bot.py` | `compose()` — LLM path + deterministic template fallback (26 trigger kinds) |
| `conversation_handlers.py` | `respond()` — multi-turn state machine (auto-reply, intent, graceful exit) |
| `server.py` | FastAPI app exposing the 5 live-harness endpoints |
| `generate_submission.py` | Runs `compose()` over the 30 canonical test pairs → `submission.jsonl` |
| `submission.jsonl` | Generated output for all 30 required test pairs |

## Running it

```bash
# Generate submission.jsonl (offline, deterministic template path)
python3 generate_submission.py --dataset /path/to/dataset_expanded

# Run with the LLM path instead
export ANTHROPIC_API_KEY=sk-...
python3 generate_submission.py --dataset /path/to/dataset_expanded

# Run the live server
pip install fastapi uvicorn
uvicorn server:app --host 0.0.0.0 --port 8080

# Self-test against the harness simulator (from the challenge zip)
export BOT_URL=http://localhost:8080
python3 judge_simulator.py
```

Note: `dataset_expanded/` is generated from the challenge zip's seed files via
`dataset/generate_dataset.py --out ./dataset_expanded` (deterministic, fixed seed —
same output for every participant).
